Computer Vision checkpoints:
  detection.pth: distinct checkpoint from final.ipynb (full-video detection)
  anticipation.pth: distinct checkpoint from main.ipynb (pre-event anticipation)

The original CV project archive did not include either checkpoint. Do not copy one
state dictionary into both paths. Verify the architecture before use.

NLP checkpoint:
  nlp_classical.joblib: generated locally by scripts/train_nlp_inference.py
  It is not included in this ZIP because the team's raw train_data.csv was not
  included. It contains the TF-IDF vectorizers, Logistic Regression classifier,
  reviewer/product target maps, scaler and calibration parameters.

The team's Transformer weights/tokenizer were also not included. The saved
classical_probs.npz and transformer_probs.npz are evaluation probability arrays,
not deployable model weights. They cannot run inference on arbitrary new text.
