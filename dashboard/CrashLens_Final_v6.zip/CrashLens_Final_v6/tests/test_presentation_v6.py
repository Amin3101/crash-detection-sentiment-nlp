"""Final v6 presentation structure and NLP dashboard integration checks."""
import ast
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
CODE = (ROOT / "app.py").read_text(encoding="utf-8")
TREE = ast.parse(CODE)


def test_five_pages_and_independent_workstreams():
    pages = [
        n for n in ast.walk(TREE)
        if isinstance(n, ast.Call)
        and isinstance(n.func, ast.Attribute)
        and n.func.attr == "Page"
    ]
    assert len(pages) == 5
    assert len([
        p for p in pages
        if p.args and isinstance(p.args[0], ast.Name)
        and p.args[0].id.startswith(("cv_", "inference_"))
    ]) == 4
    assert len([
        p for p in pages
        if p.args and isinstance(p.args[0], ast.Name)
        and p.args[0].id == "nlp_workspace"
    ]) == 1
    assert 'st.Page(nlp_workspace, title="NLP Dashboard & Run Model"' in CODE


def test_architectures_and_eda_remain_on_cv_overview():
    fn = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "cv_overview_v5")
    src = ast.get_source_segment(CODE, fn)
    assert "architecture_detection.png" in src
    assert "architecture_anticipation.png" in src
    assert "Weather" in src and "Scene" in src and "Light conditions" in src
    assert "0.944" in src and "0.785" in src
    assert "Model B" in src


def test_cv_research_and_error_pages_are_preserved():
    fn = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "cv_research_v5")
    src = ast.get_source_segment(CODE, fn)
    for call in [
        "project_journey(compact=True)",
        "experiment_history(compact=True)",
        "model_lab(compact=True)",
        "data_audit(compact=True)",
    ]:
        assert call in src
    assert (ROOT / "data" / "log_map.json").exists()
    assert len(pd.read_csv(ROOT / "data" / "experiment_history.csv")) == 68
    assert "st.Page(inference_console" in CODE
    assert "safe_video_path" in CODE


def test_original_nlp_dashboard_has_all_eight_tabs():
    dashboard = (ROOT / "assets" / "nlp_team_dashboard.html").read_text(encoding="utf-8")
    assert "Amazon electronics reviews" in dashboard
    for label in [
        "Overview", "Ratings (Q1)", "Words (Q2)", "Reviewers & votes (Q3)",
        "Text length (Q4)", "Products & brands (Q5, Q6)",
        "Warranty (part 2)", "Model (part 3)",
    ]:
        assert label in dashboard
    assert "const D = {" in dashboard
    assert "RENDER = {overview: renderOverview" in dashboard


def test_team_nlp_probabilities_and_submission_are_preserved():
    source = ROOT / "sources" / "nlp_team" / "amazon-sentiment"
    with np.load(source / "results" / "model_probabilities" / "classical_probs.npz") as p:
        assert p["Pa"].shape == (20_000, 5)
        assert p["Pb"].shape == (20_000, 5)
        assert p["Pt"].shape == (20_000, 5)
    with np.load(source / "results" / "model_probabilities" / "transformer_probs.npz") as p:
        assert p["Pa"].shape == (20_000, 5)
    submission = pd.read_csv(source / "results" / "submission_2q.csv")
    assert list(submission.columns) == ["predicted"]
    assert len(submission) == 20_000
    assert submission.predicted.between(1, 5).all()


def test_nlp_runner_is_explicit_about_missing_weights_and_supports_classical_training():
    assert "def nlp_workspace" in CODE
    assert "components.html(_nlp_dashboard_html()" in CODE
    assert "def _nlp_single_review" in CODE
    assert "def _nlp_batch_reviews" in CODE
    assert "train_deployable_classical" in CODE
    assert "Transformer weights" in CODE
    assert (ROOT / "nlp_runtime.py").exists()
    assert (ROOT / "scripts" / "train_nlp_inference.py").exists()


def test_no_old_nlp_artifacts_are_mixed_into_final_dashboard():
    assert not (ROOT / "data" / "nlp").exists()
    assert not (ROOT / "sources" / "nlp").exists()
    assert (ROOT / "sources" / "nlp_team" / "amazon-sentiment" / "docs" / "REPORT_fa.md").exists()


def test_cv_checkpoints_are_not_fabricated():
    assert not (ROOT / "models" / "detection.pth").exists()
    assert not (ROOT / "models" / "anticipation.pth").exists()


