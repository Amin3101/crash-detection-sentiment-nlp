"""Unit tests for the deployable NLP classical runner."""
from pathlib import Path
import sys

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from nlp_runtime import train_deployable_classical, predict_reviews


def test_train_and_score_synthetic_reviews(tmp_path):
    phrases = {
        1: ["terrible broken unusable", "awful failed returned"],
        2: ["poor disappointing weak", "not good and unreliable"],
        3: ["average acceptable ordinary", "neutral mixed experience"],
        4: ["good useful reliable", "happy with purchase"],
        5: ["excellent amazing perfect", "love this great quality"],
    }
    rows = []
    for rating in range(1, 6):
        for i in range(60):
            text = phrases[rating][i % 2]
            rows.append({
                "overall": rating,
                "reviewText": text + ". " + ("I recommend it." if rating >= 4 else "I do not recommend it."),
                "summary": f"{rating} star review",
                "reviewerID": f"user-{i % 18}",
                "asin": f"product-{i % 12}",
            })
    train_csv = tmp_path / "train_data.csv"
    model_path = tmp_path / "nlp_classical.joblib"
    pd.DataFrame(rows).to_csv(train_csv, index=False)

    trained = train_deployable_classical(
        train_csv, model_path, n_train=180, validation_size=50,
        max_features_review=300, max_features_summary=100, min_df=1,
    )
    assert model_path.exists()
    assert trained["metrics"]["validation_b_samples"] == 25

    one = pd.DataFrame([{
        "reviewText": "excellent amazing perfect, works great",
        "summary": "great",
        "reviewerID": "user-1",
        "asin": "product-01",
    }])
    result = predict_reviews(one, model_path)
    assert result["calibrated_probabilities"].shape == (1, 5)
    assert np.allclose(result["calibrated_probabilities"].sum(axis=1), 1.0)

    batch = pd.concat([one] * 1000, ignore_index=True)
    shifted = predict_reviews(batch, model_path, apply_label_shift=True)
    assert shifted["corrected_probabilities"].shape == (1000, 5)
    assert np.allclose(shifted["corrected_probabilities"].sum(axis=1), 1.0)
