"""Smoke tests for preserved Computer Vision sources and the merged NLP archive."""
import json
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]


class TestFinalSourceIntegrity(unittest.TestCase):
    def test_nexar_eda_figures(self):
        for name in ("weather", "scene", "light_conditions"):
            path = BASE / "assets" / "eda" / f"{name}.png"
            self.assertGreater(path.stat().st_size, 1000)
        self.assertGreaterEqual(len(pd.read_csv(BASE / "data" / "runs.csv")), 3)

    def test_original_nlp_dashboard_and_report(self):
        dashboard = (BASE / "assets" / "nlp_team_dashboard.html").read_text(encoding="utf-8")
        self.assertIn("Amazon electronics reviews", dashboard)
        self.assertIn("Warranty (part 2)", dashboard)
        self.assertIn("Model (part 3)", dashboard)
        report = (BASE / "sources" / "nlp_team" / "amazon-sentiment" / "docs" / "REPORT_fa.md").read_text(encoding="utf-8")
        self.assertIn("۰٫۶۱۲", report)
        self.assertIn("برچسب‌های آزمون پنهان‌اند", report)

    def test_team_model_probabilities_and_submission(self):
        root = BASE / "sources" / "nlp_team" / "amazon-sentiment"
        with np.load(root / "results" / "model_probabilities" / "classical_probs.npz") as p:
            self.assertEqual(p["Pb"].shape, (20000, 5))
            self.assertEqual(p["yb"].shape, (20000,))
        with np.load(root / "results" / "model_probabilities" / "transformer_probs.npz") as p:
            self.assertEqual(p["Pb"].shape, (20000, 5))
        sub = pd.read_csv(root / "results" / "submission_2q.csv")
        self.assertEqual(list(sub.columns), ["predicted"])
        self.assertEqual(len(sub), 20000)
        self.assertTrue(sub["predicted"].between(1, 5).all())

    def test_nlp_raw_training_data_and_deployable_weights_are_not_claimed(self):
        root = BASE / "sources" / "nlp_team" / "amazon-sentiment"
        self.assertFalse((root / "data" / "train_data.csv").exists())
        self.assertFalse((BASE / "models" / "nlp_classical.joblib").exists())
        self.assertFalse((BASE / "models" / "nlp_transformer").exists())


if __name__ == "__main__":
    unittest.main()
