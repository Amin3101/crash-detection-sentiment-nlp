"""Train a deployable classical NLP checkpoint for CrashLens.

Example (run from CrashLens project root):
    python scripts/train_nlp_inference.py --train-csv sources/nlp_team/amazon-sentiment/data/train_data.csv

The source ZIP does not include train_data.csv. Obtain the team's original data
file before running this script. This trains only the classical branch.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from nlp_runtime import find_training_csv, train_deployable_classical


def parse_args():
    parser = argparse.ArgumentParser(description="Train the deployable CrashLens NLP classical model.")
    parser.add_argument("--train-csv", default=None, help="Path to the labelled train_data.csv.")
    parser.add_argument("--output", default="models/nlp_classical.joblib", help="Where to save the trained artifact.")
    parser.add_argument("--n-train", type=int, default=200_000, help="Training rows sampled from the training pool.")
    parser.add_argument("--validation-size", type=int, default=40_000, help="Held-out validation rows.")
    parser.add_argument("--max-features-review", type=int, default=300_000)
    parser.add_argument("--max-features-summary", type=int, default=100_000)
    parser.add_argument("--min-df", type=int, default=3)
    return parser.parse_args()


def main():
    args = parse_args()
    train_csv = Path(args.train_csv) if args.train_csv else find_training_csv()
    if train_csv is None:
        raise SystemExit(
            "train_data.csv was not found. Put it in "
            "'sources/nlp_team/amazon-sentiment/data/train_data.csv' "
            "or pass --train-csv <path>."
        )
    output = Path(args.output)
    if not output.is_absolute():
        output = ROOT / output

    def log(message: str):
        print(message, flush=True)

    result = train_deployable_classical(
        train_csv=train_csv,
        output_path=output,
        n_train=args.n_train,
        validation_size=args.validation_size,
        max_features_review=args.max_features_review,
        max_features_summary=args.max_features_summary,
        min_df=args.min_df,
        log_callback=log,
    )
    print("\nTraining completed.")
    print(f"Checkpoint: {result['path']}")
    print(f"Validation B micro-F1: {result['metrics']['validation_b_micro_f1']:.4f}")
    print(f"Validation B macro-F1: {result['metrics']['validation_b_macro_f1']:.4f}")


if __name__ == "__main__":
    main()
